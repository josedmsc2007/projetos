package Batalha_de_personagens;

public enum ClassePersonagem {

    MAGO,
    GUERREIRO,
    ARQUEIRO

}
