package Batalha_de_personagens;

import java.util.Random;
import java.util.Scanner;
public class Main {


        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            Random random = new Random();

            System.out.println("=== CRIAÇÃO DE PERSONAGEM ===");
            System.out.print("Digite o nome do seu herói: ");
            String nomeHeroi = scanner.nextLine();

            System.out.println("Escolha a Classe: 1-MAGO, 2-GUERREIRO, 3-ARQUEIRO");
            int opcClasse = scanner.nextInt();
            ClassePersonagem classeEscolhida = ClassePersonagem.values()[opcClasse - 1];

            System.out.println("\nEscolha seu Mascote:");
            int index = 1;
            for (TipoMascote tm : TipoMascote.values()) {
                if (tm.getClassePermitida() == classeEscolhida) {
                    System.out.println(index + "- " + tm.name() + " (" + tm.getHabilidade() + " +" + tm.getValorEfeito() + ")");
                }
                index++;
            }
            int opcMascote = scanner.nextInt();
            TipoMascote mascoteEscolhido = TipoMascote.values()[opcMascote - 1];

            // Criação do objeto do jogador
            Personagem jogador = new Personagem(nomeHeroi, 100, 30, 10, 1, classeEscolhida, mascoteEscolhido);

            // Geração do inimigo aleatório
            ClassePersonagem classeInimigo = ClassePersonagem.values()[random.nextInt(ClassePersonagem.values().length)];
            Personagem inimigo = new Personagem("Inimigo Sombrio", 80, 25, 8, 1, classeInimigo, null);

            System.out.println("\n==================================");
            System.out.println("A BATALHA VAI COMEÇAR!");
            System.out.println("==================================");

            // Loop de Batalha
            while (jogador.estaVivo() && inimigo.estaVivo()) {
                System.out.println("\n--- Status Atual ---");
                jogador.exibirEstado();
                inimigo.exibirEstado();

                System.out.println("\nSua vez! Escolha a ação:");
                System.out.println("1 - Atacar");
                System.out.println("2 - Defender");
                int acao = scanner.nextInt();

                // Ação do Jogador
                if (acao == 1) {
                    jogador.atacar(inimigo);
                } else {
                    jogador.defender();
                }

                // Verifica se o inimigo morreu antes de atacar
                if (!inimigo.estaVivo()) {
                    System.out.println("\nVitória! Você derrotou o " + inimigo.getNome() + "!");
                    break;
                }

                // Ação Aleatória do Inimigo (Controlado pelo Sistema)
                System.out.println("\nTurno do Inimigo...");
                int acaoInimigo = random.nextInt(2); // 0 ou 1
                if (acaoInimigo == 0) {
                    inimigo.atacar(jogador);
                } else {
                    inimigo.defender();
                }

                if (!jogador.estaVivo()) {
                    System.out.println("\nDerrota! Você foi eliminado.");
                }
            }

            scanner.close();
            System.out.println("=== FIM DE JOGO ===");
        }
}