package Batalha_de_personagens;

public enum TipoMascote {

    // Mascotes de Mago
    FADA(ClassePersonagem.MAGO, "Cura", 20),
    CORUJA(ClassePersonagem.MAGO, "Ataque Mágico", 15),

    // Mascotes de Guerreiro
    LOBO(ClassePersonagem.GUERREIRO, "Ataque Físico", 15),
    TARTARUGA(ClassePersonagem.GUERREIRO, "Defesa", 20),

    // Mascotes de Arqueiro
    FALCAO(ClassePersonagem.ARQUEIRO, "Ataque Rápido", 15),
    TIGRE(ClassePersonagem.ARQUEIRO, "Ataque Sangrento", 20);

    private final ClassePersonagem classePermitida;
    private final String habilidade;
    private final int valorEfeito;

    TipoMascote(ClassePersonagem classePermitida, String habilidade, int valorEfeito) {
        this.classePermitida = classePermitida;
        this.habilidade = habilidade;
        this.valorEfeito = valorEfeito;
    }

    public ClassePersonagem getClassePermitida() {
        return classePermitida;
    }

    public String getHabilidade() {
        return habilidade;
    }

    public int getValorEfeito() {
        return valorEfeito;
    }
}
