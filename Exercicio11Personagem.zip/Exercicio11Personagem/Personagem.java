/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.unipar.poo.Exercicio11Personagem;

import java.util.Random;

public class Personagem {

    private String nome;
    private int vida1 = 100;
    private int vida2 = 100;
    private int soco;
    private int chute;

    public Personagem() {
    }

    public String getNome() {
        return nome;
    }

    public int getVida1() {
        if (vida1 <= 0) {
            vida1 = 0;
            System.out.println("adversario morreu");
        }
        return vida1;
    }

    public int getVida2() {
        if (vida2 <= 0) {
            vida2 = 0;
            System.out.println("voce morreu");
        }
        return vida2;
    }

    public int getSoco() {
        return soco;
    }

    public int getChute() {
        return chute;
    }

    public String danoSoco(int soco) {
        Random danosoco = new Random();
        soco = danosoco.nextInt(90);
        if (soco > 80) {
            vida1 -= soco;
            return " voce deu um soco na cabeca de " + soco + "\n adversario ficou com " + getVida1() + " de vida";
        } else if (soco > 50 && soco < 80) {
            vida1 -= soco;
            return "voce deu um soco no peito de " + soco + "\n adversario ficou com " + getVida1() + " de vida";
        } else if (soco < 50) {
            return " seu soco foi bloqueado \n adversario ficou com " + getVida1() + " de vida";
        }
        return " seu soco foi bloqueado \n adversario ficou com " + getVida1() + " de vida";
    }

    public String danoChute(int chute) {
        Random danochute = new Random();
        chute = danochute.nextInt(60);
        if (chute > 50) {
            vida1 -= chute;
            return "voce deu um chute na costela de " + chute + "\n adversario ficou com " + getVida1() + " de vida";
        } else if (chute > 20 && chute < 50) {
            vida1 -= chute;
            return " voce deu um chute na coxa de  " + chute + "\n adversario ficou com " + getVida1() + " de vida";
        } else if (chute < 20) {
            return " seu chute foi bloqueado \n adversario ficou com " + getVida1() + " de vida";
        } else {
            return " seu chute foi bloqueado \n adversario ficou com " + getVida1() + " de vida";
        }
    }

    public String danoInimigo(int Inimigo) {
        if (vida1 <= 0) {
            return "O adversario morreu.";
        }
        Random danoinimigo = new Random();
        Inimigo = danoinimigo.nextInt(50);
        vida2 -= Inimigo;
        return " o adversario contra golpeou e causou " + Inimigo + " de dano \n voce ficou com " + getVida2() + " de vida";
    }

}
