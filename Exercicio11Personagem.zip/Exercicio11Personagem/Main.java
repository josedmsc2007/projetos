/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.unipar.poo.Exercicio11Personagem;

import java.util.Scanner;

/**
 *
 * @author jose
 */
public class Main {

    public static void main(String[] args) {
        Personagem p1 = new Personagem();

        Scanner ler = new Scanner(System.in);

        System.out.println("Bem vindo ao Ringue da Vizinhanca! isso, isso, isso!");
        System.out.println("");
        System.out.println("");
        System.out.println("Escolha seu personagem!");
        System.out.println("");
        System.out.println("<1> para Chaves");
        System.out.println("<2> para Quico");

        System.out.println("");

        System.out.println("escolha seu golpe");
        System.out.println("Digite <soco> para efetuar um soco no seu oponente");
        System.out.println("Digite <chute> para efetuar um chute no seu oponente");
        System.out.println("Digite <sair> para encerrar o jogo");

        while (true) {
            switch (ler.nextLine()) {
                case "1":
                    System.out.println("Seu personagem e o chavinho, ninguem tem paciencia comigo!");
                    System.out.println("seu personagem tem 100 de vida");
                    break;

                case "2":
                    System.out.println("Seu Personagem e o Quico, gentalha!, gentalha!");
                    System.out.println("seu personagem tem 100 de vida");
                    break;

                case "soco":
                    System.out.println(p1.danoSoco(0));
                    System.out.println();
                    System.out.println(p1.danoInimigo(0));
                    break;
                case "chute":
                    System.out.println(p1.danoChute(0));
                    System.out.println();
                    System.out.println(p1.danoInimigo(0));
                    break;
                case "sair":
                    System.out.println("voce saiu do jogo, execute novamante para jogar!");
                    return;

                default:
                    System.out.println("Comando invalido, tente novamente!");
                    break;
            }
        }

    }
}
