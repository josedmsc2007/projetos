package Batalha_de_personagens;

import java.util.Random;

public enum ClassePersonagem {

    MAGO(35, 5),
    GUERREIRO(25, 15),
    ARQUEIRO(30, 10);

    private int forca;
    private int defesa;

    ClassePersonagem(int forca, int defesa) {
        this.forca = forca;
        this.defesa = defesa;
    }

    public int getForca() {
        return forca;
    }

    public int getDefesa() {
        return defesa;
    }

    // Metodo para pegar uma classe aleatória
    public static ClassePersonagem classeAleatoria() {
        Random random = new Random();
        ClassePersonagem[] classes = values();
        return classes[random.nextInt(classes.length)];
    }
}
