package Batalha_de_personagens;

import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;
public class Main {


        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            Random random = new Random();


            System.out.println("\n==================================");
            System.out.println("A BATALHA VAI COMEÇAR!");
            System.out.println("==================================");
            System.out.println("CLASSES E SUAS CARACTERISTOCAS");
            System.out.println();
            System.out.println("MAGO: ");
            System.out.println("Vida: 100 | Força: 35 | Defesa: 5");
            System.out.println("Pets do Mago: Fada: Cura +10 de vida | Coruja: Ataque Mágico +5 de dano");
            System.out.println("------------------------------------");
            System.out.println("GUERREIRO: ");
            System.out.println("Vida: 100 | Força: 25 | Defesa: 15");
            System.out.println("Pets do Mago: Lobo: Ataque físico +15 de dano | Tartaruga: +10 de defesa");
            System.out.println("------------------------------------");
            System.out.println("ARQUEIRO: ");
            System.out.println("Vida: 100 | Força: 30 | Defesa: 10");
            System.out.println("Pets do Mago: Falcao: Ataque rapido +15 de dano | Tigre: Ataque sangrento +20 de dano");
            System.out.println("------------------------------------");
            System.out.println("!!! OBS: O PET SO VAI AJUDAR APOS DOIS COMANDOS !!!");
            System.out.println();
            System.out.println();
            System.out.println("=== CRIAÇÃO DE PERSONAGEM ===");
            System.out.print("Digite o nome do seu herói: ");
            String nomeHeroi = scanner.nextLine();

            System.out.println("Escolha a Classe: 1-MAGO, 2-GUERREIRO, 3-ARQUEIRO");
            int opcClasse = scanner.nextInt();
            ClassePersonagem classeEscolhida = ClassePersonagem.values()[opcClasse - 1];

            System.out.println("\nEscolha seu Mascote:");
            int index = 1;
            for (TipoMascote tm : TipoMascote.values()) {
                if (tm.getClassePermitida() == classeEscolhida) {
                    System.out.println(index + "- " + tm.name() + " (" + tm.getHabilidade() + " +" + tm.getValorEfeito() + ")");
                }
                index++;
            }
            int opcMascote = scanner.nextInt();
            TipoMascote mascoteEscolhido = TipoMascote.values()[opcMascote - 1];

            // Criação do objeto do jogador
            Personagem jogador = new Personagem(
                    nomeHeroi,
                    100,
                    classeEscolhida.getForca(),
                    classeEscolhida.getDefesa(),
                    1,
                    classeEscolhida,
                    mascoteEscolhido
            );

            // Geração do inimigo aleatório
            ClassePersonagem classeInimigo = ClassePersonagem.classeAleatoria();

            Personagem inimigo = new Personagem(
                    "Inimigo Sombrio",
                    100,
                    classeInimigo.getForca(),
                    classeInimigo.getDefesa(),
                    1,
                    classeInimigo,
                    null
            );



            // Loop de Batalha
            while (jogador.estaVivo() && inimigo.estaVivo()) {
                System.out.println("\n--- Status Atual ---");
                jogador.exibirEstado();
                inimigo.exibirEstado();

                System.out.println("\nSua vez! Escolha a ação:");
                System.out.println("1 - Atacar");
                System.out.println("2 - Defender");
                int acao = scanner.nextInt();

                // Ação do Jogador
                if (acao == 1) {
                    jogador.atacar(inimigo);
                } else {
                    jogador.defender();
                }

                // Verifica se o inimigo morreu antes de atacar
                if (!inimigo.estaVivo()) {
                    System.out.println("\nVitória! Você derrotou o " + inimigo.getNome() + "!");
                    break;
                }

                // Ação Aleatória do Inimigo (Controlado pelo Sistema)
                System.out.println("\nTurno do Inimigo...");
                int acaoInimigo = random.nextInt(2); // 0 ou 1
                if (acaoInimigo == 0) {
                    inimigo.atacar(jogador);
                } else {
                    inimigo.defender();
                }

                if (!jogador.estaVivo()) {
                    System.out.println("\nDerrota! Você foi eliminado.");
                }
            }

            scanner.close();
            System.out.println("=== FIM DE JOGO ===");
        }
}